// *** Configurable variables for the app ***
// This file contains all the user-editable configuration values that can be updated when customizing the chatbot app.

export const APP_CONFIG = {
  // UPDATE: Set to the welcome message for the chatbot
  WELCOME_MESSAGE: ".Hi! I’m your AI Mechanical Assistant. Ask me anything about machine issues, from unusual bearing noises to parts replacement. I’m here to help you extend your machine's life.. ",

  // UPDATE: Set to the name of the chatbot app
  NAME: "TechnicianAI",

  // UPDATE: Set to the description of the chatbot app
  DESCRIPTION: "I provide expert solutions for any machine problem. I'll guide you through simple, step-by-step repairs—just show me your machine and I'll help you fix it\nShow me your machine and I am here to fix.",
} as const;

// Colors Configuration - UPDATE THESE VALUES BASED ON USER DESIGN PREFERENCES
export const COLORS = {
  // UPDATE: Set to the background color (hex format)
  BACKGROUND: "#FFFFFF",

  // UPDATE: Set to the primary color for buttons, links, etc. (hex format)
  PRIMARY: "#ff00ff",
} as const;
