import { NextRequest, NextResponse } from "next/server";

const PI_API_BASE = "https://api.minepi.com";
const PI_SERVER_API_KEY = process.env.PI_SERVER_API_KEY;

export async function POST(req: NextRequest) {
  if (!PI_SERVER_API_KEY) {
    return NextResponse.json(
      { error: "Server API key is not configured." },
      { status: 500 }
    );
  }

  let body: { payment_id?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const { payment_id } = body;

  if (!payment_id) {
    return NextResponse.json(
      { error: "Missing payment_id." },
      { status: 400 }
    );
  }

  try {
    // Fetch payment details from the Pi Platform using the Server API Key
    const piResponse = await fetch(`${PI_API_BASE}/v2/payments/${payment_id}`, {
      method: "GET",
      headers: {
        Authorization: `Key ${PI_SERVER_API_KEY}`,
      },
    });

    if (!piResponse.ok) {
      const errorData = await piResponse.json().catch(() => ({}));
      return NextResponse.json(
        { error: "Failed to retrieve payment from Pi Network.", details: errorData },
        { status: piResponse.status }
      );
    }

    const paymentData = await piResponse.json();

    return NextResponse.json({
      success: true,
      payment: paymentData,
    });
  } catch (err) {
    return NextResponse.json(
      { error: "Failed to verify payment with Pi Network." },
      { status: 500 }
    );
  }
}

export async function PUT(req: NextRequest) {
  if (!PI_SERVER_API_KEY) {
    return NextResponse.json(
      { error: "Server API key is not configured." },
      { status: 500 }
    );
  }

  let body: { payment_id?: string; action?: "approve" | "complete" };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const { payment_id, action } = body;

  if (!payment_id || !action) {
    return NextResponse.json(
      { error: "Missing payment_id or action." },
      { status: 400 }
    );
  }

  if (action !== "approve" && action !== "complete") {
    return NextResponse.json(
      { error: "Invalid action. Must be 'approve' or 'complete'." },
      { status: 400 }
    );
  }

  try {
    const endpoint =
      action === "approve"
        ? `${PI_API_BASE}/v2/payments/${payment_id}/approve`
        : `${PI_API_BASE}/v2/payments/${payment_id}/complete`;

    const piResponse = await fetch(endpoint, {
      method: "POST",
      headers: {
        Authorization: `Key ${PI_SERVER_API_KEY}`,
        "Content-Type": "application/json",
      },
    });

    if (!piResponse.ok) {
      const errorData = await piResponse.json().catch(() => ({}));
      return NextResponse.json(
        { error: `Failed to ${action} payment.`, details: errorData },
        { status: piResponse.status }
      );
    }

    const paymentData = await piResponse.json();

    return NextResponse.json({
      success: true,
      action,
      payment: paymentData,
    });
  } catch (err) {
    return NextResponse.json(
      { error: `Failed to ${action} payment with Pi Network.` },
      { status: 500 }
    );
  }
}
