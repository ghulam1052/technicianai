import { NextResponse } from "next/server"

export async function GET() {
  const key =
    "0337d147baffdec54cc85ac028aab310c75985bbe3e4deb7ccb75cc91f9409eb04ab90592818ee213fdf94b29c27146a38dba8b09966e4418f077bb337673f82"

  return new NextResponse(key, {
    status: 200,
    headers: {
      "Content-Type": "text/plain",
    },
  })
}
