import { NextRequest, NextResponse } from "next/server";

const PI_API_BASE = "https://api.minepi.com";
const PI_SERVER_API_KEY = process.env.PI_SERVER_API_KEY;

export async function POST(req: NextRequest) {
  if (!PI_SERVER_API_KEY) {
    return NextResponse.json(
      { error: "Server API key is not configured." },
      { status: 500 }
    );
  }

  let body: { pi_auth_token?: string; app_id?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const { pi_auth_token, app_id } = body;

  if (!pi_auth_token) {
    return NextResponse.json(
      { error: "Missing pi_auth_token." },
      { status: 400 }
    );
  }

  try {
    // Verify the user's access token with the Pi Platform
    const piResponse = await fetch(`${PI_API_BASE}/v2/me`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${pi_auth_token}`,
      },
    });

    if (!piResponse.ok) {
      const errorData = await piResponse.json().catch(() => ({}));
      return NextResponse.json(
        { error: "Pi Network authentication failed.", details: errorData },
        { status: 401 }
      );
    }

    const userData = await piResponse.json();

    return NextResponse.json({
      success: true,
      user: {
        uid: userData.uid,
        username: userData.username,
      },
      ...(app_id ? { app_id } : {}),
    });
  } catch (err) {
    return NextResponse.json(
      { error: "Failed to verify authentication with Pi Network." },
      { status: 500 }
    );
  }
}
